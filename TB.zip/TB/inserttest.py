from flask import Flask, render_template, request
import pymysql
app = Flask(__name__)
db = pymysql.connect('localhost', 'root', '', '205cde proj')
cursor = db.cursor()

sql = '''INSERT INTO login(email, username, password) VALUES ('YNK@gmail.com', 'YNK', '1234')'''

cursor.execute(sql)
db.commit()


db.close()