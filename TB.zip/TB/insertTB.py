#Assume you have a table called user created in the database and the attributes of 
#user table are id, username, password 
from flask import Flask, render_template
import pymysql
app = Flask(__name__) 
#open database connection
db = pymysql.connect(‘localhost’, ‘USERNAME’, ‘’, ‘205cde proj’)
 
@app.route("/signUp", methods = ['POST', 'GET']) 
def signup():
	error = None
	if request.method == 'POST':
	usrname = request.form["username"]
	pwd = request.form['password'] 
 
# prepare a cursor object using cursor() method
cursor = db.cursor()
#maxid = cursor.fetchone()
# Execute the SQL command
cursor.execute("""INSERT INTO login (email, password, username) VALUES ('ambrose609@gmail.com',' 123qweasd', 'Hin')""", (usrname, pwd)) 

 
# Commit your changes in the database
db.commit() return render_template("signUp.html", error = error) 
 
db.close() 
 