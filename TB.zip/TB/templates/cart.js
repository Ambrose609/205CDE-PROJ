Gnames = []
Gdate = []
Gprice = []

function addItem(){

  Gname.push(document.getElementById('GameName').value)
  Gdate.push(document.getElementById('Date').value)
  Gprice.push(document.getElementById('Price').value)

  displayCart()
}

function displayCart(){

	cartdata = '<table><tr><th>Game Name</th><th>Quantity</th><th>Price</th><th>total</th></tr>';

	total  = 0;

	for (i=0; i<Gnames.lenght; i++){
		total += Gprice[i]
		cartdata += "<tr><td>" + Gname[i] + "</td><td>" + Gdate[i] + "</td><td>" +Gprice[i] + "</td><td>" + Gprice[i] + "</td><td><button onclick='delElement(" + i + ")'>Delete</button></td></tr>"
	}


	cartdata += '<tr><td></td><td></td><td></td><td>' + total + '</td></tr></table>'


	document.getElementById('cart').innerHTML = cartdata



}

function addItem(){
  Gnames = []
  Gdate = []
  Gprice = []


  Gname.push(document.getElementById('GameName').value)
  Gdate.push(document.getElementById('GameDate').value)
  Gprice.push(document.getElementById('GamePrice').value)

  displayCart()
}

function displayCart(){

  cartdata = '<table><tr><th>Game Name</th><th>Date</th><th>Price</th><th>total</th></tr>';

  total  = 0;

  for (i=0; i<Gnames.lenght; i++){
    total += Gprice[i]
    cartdata += "<tr><td>" + Gname[i] + "</td><td>" + Gdate[i] + "</td><td>" +Gprice[i] + "</td><td>" + Gprice[i] + "</td><td><button onclick='delElement(" + i + ")'>Delete</button></td></tr>"
  }


  cartdata += '<tr><td></td><td></td><td></td><td>' + total + '</td></tr></table>'


  document.getElementById('cart').innerHTML = cartdata



}