from flask import Flask, session 
app = Flask(__name__)
app.secret_key = ‘any random string’

@app.route("/login", methods=['POST', 'GET'])
def login():
	if request.method == 'POST':
		usrname = request.form["username"]
		pwd = request.form['password']

		cursor = db.cursor()



		sql = ("SELECT username, password From user WHERE username = '"+usrname+"'")
		cursor.execute(sql)

		db.commit()
		results = cursors.fetchall()
		for row in results:
			custName = row[0]
			custPassword = row[1]

			session['username'] = custName
			return redirect(url_for('customer', guest = custName))