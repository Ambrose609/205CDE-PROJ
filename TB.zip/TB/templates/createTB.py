import pymysql.cursors

#create database
connection = pymysql.connect(host='localhost, user='root' port=3306, password='')

try:
	with connection.cursors() as cursor:
		cursor.execute('CREARE DATABASE GAMEEEE_databases'
			)


finally:
	connection.close()