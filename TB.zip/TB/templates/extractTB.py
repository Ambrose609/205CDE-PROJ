from flask import Flask, render_template
import pymysql
app = Flask(__name__)
#open database connection 
db = pymysql.connect(‘localhost’, ‘USERNAME’, ‘PASSWORD’, ‘DATABASE_NAME’) 

@app.route("/login", methods=['POST', 'GET']) 
def login():
	error = None
	if request.method == 'POST':
		usrname = request.form["username"]
		pwd = request.form['password']
 
# prepare a cursor object using cursor() method 
cursor = db.cursor()
#maxid = cursor.fetchone()
# Execute the SQL command
sql = ("SELECT username, password FROM user WHERE username = '"+usrname+"'")
cursor.execute(sql)
# Commit your changes in the database
db.commit() 
results = cursor.fetchall()
for row in results:
	custName = row[0]
	custPassword = row[1]
	print ("Customer Name = %s, Password  = %s" % (custName, custPassword))
	return redirect(url_for('customer', guest = custName)) 
 
##custPwd = password 
return render_template("Login2.html", error = error) 
db.close() 
 
 
@app.route("/guest/<guest>") 
def customer(guest): 
	return "Hello %s! You are a customer!" % guest