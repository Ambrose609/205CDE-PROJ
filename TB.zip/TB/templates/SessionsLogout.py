from flask import Flask, session 
app = Flask(__name__)

@app.route("/logout")
def logout():
	# remove the username from the session of it is there
	session.pop('username', None)
	return 'Hello 205CDE!'
	#redirect(url_for('index'))