from flask import Flask, session 
app = Flask(__name__)

@app.route("/index")
@app.route("/")
def index():
	if 'username' in session:
		return 'Logged in as ' + session['username'] + '<br>' + "<a href = '/logout'>Click here to log out</a>"
	else:
		return "Hello 205CDE Class! You are not logged in in <br><a href= '/login'>Click here to log in</a>"